package OOAD_Project;

public class Application {
	public static void main(String[] args) {
		AppFirstPage app = new AppFirstPage();
		app.setVisible(true);
		app.toFront();
	}

}
